const apiHost = 'https://nexus-oauth.duckdns.org/api';

const rand = () => Math.random(0).toString(36).substr(2);
const token = (length) => (rand() + rand() + rand() + rand()).substr(0, length);

function loginClick() {
    const user = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    console.log('User: ' + user + '\nPassword: ' + password);

    firstStep(user, password);
}

function getClientKey() {
    var original = window.localStorage.getItem('clientKey');

    if (original == null) {
        original = token();
        window.localStorage.setItem('clientKey', original);
    }
}

function firstStep(user, password) {
    var clientKey = getClientKey();
    var url = apiHost + '/Authentications/FirstStep?user=' + user;

    var xhr = new XMLHttpRequest();
    xhr.open('GET', encodeURI(url));
    xhr.origin = origin;
    xhr.withCredentials = false;
    xhr.responseType = 'json';
    xhr.onload = function () {
        var status = xhr.status;
        console.log(status);
    }

    xhr.setRequestHeader('Client-Key', clientKey);
    xhr.send();
}